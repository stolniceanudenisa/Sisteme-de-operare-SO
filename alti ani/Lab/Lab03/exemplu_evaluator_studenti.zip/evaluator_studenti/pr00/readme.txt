Acesta este un exemplu de evaluator si are rolul de a informa mai bine studentii despre modalitatea de evaluare.
Problema din evaluator este strict pt exemplu si nu are legatura cu enunturile problemelor date ca tema.
Enuntul problemei se gaseste in fisierul "enunt.txt", iar o rezolvare corecta se afla deja in folderul "scripts"
Orice se gaseste in acest evaluator poate fi folosit ca sursa de inspiratie, dar orice tentativa de fraudare a evaluatorului nu este permisa.


Instructiuni evaluator pt studenti:
* pentru a evalua un script, acesta trebuie pus in folderul "scripts"
* apoi se poate rula fara parametri scriptul "run.sh"

