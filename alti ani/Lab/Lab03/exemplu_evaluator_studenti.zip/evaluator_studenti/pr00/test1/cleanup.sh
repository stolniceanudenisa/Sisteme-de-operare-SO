#!/bin/bash

WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

rm -r -f $WORK_DIR/execute/*


