#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "linia 1" >fis1
echo "linia 2" >>fis1
echo "linia 3" >>fis1
echo "linia 4" >>fis1
echo "linia 5" >>fis1

#cleanup
cd $PWD
