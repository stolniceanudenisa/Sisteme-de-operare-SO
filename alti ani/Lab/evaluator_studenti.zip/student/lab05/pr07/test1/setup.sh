#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "1 2 3 4 5 6 7 8 9 1 0 1 1 1 2 1 3 1 4 1 1" > fis1


#cleanup
cd $PWD
