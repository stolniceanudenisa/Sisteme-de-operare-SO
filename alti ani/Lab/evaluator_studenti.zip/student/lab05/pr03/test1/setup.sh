#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "cuv1:cuv2:cuv3:cuv4:cuv5" > fis1
echo "cuv5:cuv4:cuv3:cuv2:cuv1" > fis2

#cleanup
cd $PWD
