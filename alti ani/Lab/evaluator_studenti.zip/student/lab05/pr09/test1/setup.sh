#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "These example sentences are selected automatically from various online news sources to reflect current usage of the word proposition." > fis1


#cleanup
cd $PWD
