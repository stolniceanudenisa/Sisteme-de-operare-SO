#include  <math.h>
void f1(int myvar);

