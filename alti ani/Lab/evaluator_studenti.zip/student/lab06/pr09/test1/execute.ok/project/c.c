#include "a.h"
#include "b.h"
#include "c.h"

void f1(int myvar)
{
    return myvar/2;
}

int main()
{
    int var1,var2,var3;
    int rez;
    rez=f1(var1);
    printf("%d",rez);
    return 0;
}
