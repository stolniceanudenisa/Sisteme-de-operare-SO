#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

cp -R $WORK_DIR/execute.ok/* $WORK_DIR/execute/
for i in `find -type f`; do
    sed -i -r "s/\(var1\)/\(var2\)/g" $i
done


#cleanup
cd $PWD
