#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
cd $WORK_DIR/execute.ok/
for i in `find -type f`; do
    head -n 2 $i >$WORK_DIR/execute/$i
done

#cleanup
cd $PWD
