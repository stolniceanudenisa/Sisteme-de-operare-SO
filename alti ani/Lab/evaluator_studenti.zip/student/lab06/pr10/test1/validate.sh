#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output"
output_ok="output.ok"
output_tree="output.tree"
output_ok_tree="output.ok.tree"

# make a new tree (redirect into a file "output.tree")

cd $WORK_DIR/execute.ok
array=`ls -1`
cd $WORK_DIR

for i in $array; do
    cmp "./execute/$i" "./execute.ok/$i">/dev/null
    status=`echo $?`
    if [ $status -ne 0 ]; then  
        exit 1
    fi
done
cd $CURRENT_DIRECTORY
exit 0
