#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output.csv"
output_ok="output.ok"

cp ./execute/depozit.csv $output


cmp $output $output_ok>/dev/null
status=`echo $?`


cd $CURRENT_DIRECTORY
exit $status
