#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output"
output_ok="output.ok"
output_tree="output.tree"
output_ok_tree="output.ok.tree"

# make a new tree (redirect into a file "output.tree")
cd ./execute/dictionar
tree . >../../$output_tree
cd ../../

# check diff between "output.tree" and "output.ok.tree"
cmp $output_tree $output_ok_tree>/dev/null
status=`echo $?`
#rm $output_tree

if [ $status -ne 0 ]; then  

    # if the diff not ok, then leave with exit 1
    cd $CURRENT_DIRECTORY
    exit 1
fi
for litera in 0 1 2 3 4 5 6 7 8 9; do
    cmp "./execute/dictionar/$litera" "./execute.ok/dictionar/$litera">/dev/null
    status=`echo $?`
    if [ $status -ne 0 ]; then  
        exit 1
    fi
done
cd $CURRENT_DIRECTORY
exit 0
