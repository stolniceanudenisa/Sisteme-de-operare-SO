#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "#include <string.h>    ">fis1.c
echo "int func1(int a,int b) ">>fis1.c
echo "{                      ">>fis1.c
echo "    return a+b;        ">>fis1.c
echo "}                      ">>fis1.c
echo "void main()            ">>fis1.c
echo "{                      ">>fis1.c
echo "    func1(1,2);        ">>fis1.c
echo "}                      ">>fis1.c

#cleanup
cd $PWD
