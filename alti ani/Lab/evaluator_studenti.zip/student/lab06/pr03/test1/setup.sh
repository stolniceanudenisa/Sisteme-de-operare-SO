#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
touch studenti.csv
touch notevara.csv

echo "student1,10">studenti.csv

echo "student1,8,8,8,8,8">notevara.csv

#cleanup
cd $PWD
