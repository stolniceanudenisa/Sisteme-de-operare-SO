#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
mkdir testdir

mkdir testdir/subdir1
touch testdir/subdir1/testfile


#cleanup
cd $PWD
