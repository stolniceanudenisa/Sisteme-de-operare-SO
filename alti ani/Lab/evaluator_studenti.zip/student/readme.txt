puneti scriptul de rulat in folderul 'scripts' aflat in folderului problemei si apoi rulati scriptul 'run.sh' din folderul problemei
