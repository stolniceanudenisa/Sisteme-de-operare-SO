#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "Cum sa ajungi pe prima pagina pe 1Google - marketing online">google
echo "De multe ori lumea ne intreaba care sunt pasii ce trebuie urmati pentru a ajunge pe prima pagina a motorului de cautare Google1.">>google


#cleanup
cd $PWD
