#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
cp /bin/ls ./bin1
cp /etc/passwd ./passwd
echo "#include <string.h>"> ./bin1.c 
echo "#!/bin/bash" > script_bash.sh
echo "ls" >> script_bash.sh
echo "#!/bin/sh" > script_sh.sh
echo "ls" >> script_sh.sh
echo "#!/bin/bash" > script_bash
echo "ls" >> script_bash
echo "#!/bin/sh" > script_sh
echo "ls" >> script_sh
echo "ls" > script_ls

#cleanup
cd $PWD

