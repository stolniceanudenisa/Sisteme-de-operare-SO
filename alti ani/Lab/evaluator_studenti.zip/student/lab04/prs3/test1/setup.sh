#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

echo "Welcome to the website. If you're here, you're likely looking to find random words." >>file_example1
echo " Random Word Generator is the perfect tool to help you do this." >>file_example1
echo " While this tool isn't a word creator, it is a word generator that will generate random" >>file_example1
echo " words for a variety of activities or uses. Even better, it allows you to adjust the" >>file_example1
echo " parameters of the random words to best fit your needs." >>file_example1

echo "The first option the tool allows you to adjust is the number of random words to be generated." >>file_example1
echo " You can choose as many or as few as you'd like. You also have the option of choosing words " >>file_example1
echo "that only begin with a certain letter, only end with a certain letter or only begin and end " >>file_example1
echo "with certain letters. If you leave these blank, the randomize words that appear will be from " >>file_example1
echo "the complete list." >>file_example1

echo "You also have the option of choosing the number of syllables of the words or the word length " >>file_example1
echo "of the randomized words. There are also options to further refine by choosing less than or" >>file_example1
echo " greater than options for both syllables and word length. Again, if you leave the space blank," >>file_example1
echo " the complete list of randomized words will be used. Finally, you can choose between standard" >>file_example1
echo " text or cursive words. The cursive words will all be in cursive using cursive letters." >>file_example1

echo "Once you have input all of your specifications, all you have to do is to press the Generate " >>file_example1
echo "Random Words button, and a list of random words will appear. Below are some of the common ways " >>file_example1
echo "people use this tool." >>file_example1

cp file_example1 file_example2


#cleanup
cd $PWD
