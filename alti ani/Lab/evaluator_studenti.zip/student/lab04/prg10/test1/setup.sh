#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "intel,i5,10" > stoc.csv
echo "amd,ryzen,7" >> stoc.csv

#cleanup
cd $PWD
