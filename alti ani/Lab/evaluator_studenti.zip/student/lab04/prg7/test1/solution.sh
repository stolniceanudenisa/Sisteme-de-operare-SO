echo acest test e baza pe rularea unei solutii si nu poate fi rulat
