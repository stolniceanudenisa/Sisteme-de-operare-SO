#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output"
output_ok="output.ok"
output_tree="output.tree"
output_ok_tree="output.ok.tree"

# make a new tree (redirect into a file "output.tree")
./get_tree.sh

# check diff between "output.tree" and "output.ok.tree"
cmp $output_tree $output_ok_tree>/dev/null
status=`echo $?`

cd $CURRENT_DIRECTORY
exit $status
