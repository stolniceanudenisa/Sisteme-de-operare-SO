#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output"
output_ok="output.ok"
output_tree="output.tree"
output_ok_tree="output.ok.tree"


tree ./execute/dir1 >$output_tree
tree ./execute/dir2 >>$output_tree
tree ./execute/dir3 >>$output_tree
tree ./execute/dir4 >>$output_tree


cd $CURRENT_DIRECTORY
exit $status

