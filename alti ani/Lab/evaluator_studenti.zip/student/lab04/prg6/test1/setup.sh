#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
mkdir dir1
mkdir dir2
mkdir dir3
mkdir dir4

#fisier de sters
echo fis1>delfile.txt
echo fis2>>delfile.txt
echo fis3>>delfile.txt
echo fis4>>delfile.txt
echo fis5>>delfile.txt

touch dir1/fis1
touch dir1/fis2
touch dir1/fis3
touch dir1/fis4
touch dir1/fis5

mkdir dir1/subdir1/
touch dir1/subdir1/fis1
touch dir1/subdir1/fis2
touch dir1/subdir1/fis3
touch dir1/subdir1/fis4
touch dir1/subdir1/fis5

mkdir dir1/subdir2/
touch dir1/subdir2/fis1
touch dir1/subdir2/fis2
touch dir1/subdir2/fis3
touch dir1/subdir2/fis4
touch dir1/subdir2/fis5

mkdir dir2/subdir/
touch dir2/subdir/fis1
touch dir2/subdir/fis2
touch dir2/subdir/fis3
touch dir2/subdir/fis4
touch dir2/subdir/fis5

touch dir3/fis1
touch dir3/fis2
touch dir3/fis3
touch dir3/fis4
touch dir3/fis5
 

#cleanup
cd $PWD
