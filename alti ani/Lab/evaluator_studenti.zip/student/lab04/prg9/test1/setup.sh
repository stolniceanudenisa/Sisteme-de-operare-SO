#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
echo "IN,Salariu,3500" > popescu.csv
echo "OUT,Facturi utilitati,800" >> popescu.csv
echo "IN,Chirie,450" >> popescu.csv
echo "OUT,Rata,400" >> popescu.csv
echo "OUT,Combustibil,200" >> popescu.csv
echo "OUT,Mancare,200" >> popescu.csv

#cleanup
cd $PWD
