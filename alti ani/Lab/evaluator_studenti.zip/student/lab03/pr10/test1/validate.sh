#!/bin/bash

CURRENT_DIRECTORY=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`

cd $WORK_DIR

#defines
output="output"
output_ok="output.ok"
output_tree="output.tree"
output_ok_tree="output.ok.tree"

# make a new tree (redirect into a file "output.tree")
cd ./execute/
tree . | tail -n 1 >../$output_tree
cd ../

# check diff between "output.tree" and "output.ok.tree"
cmp $output_tree $output_ok_tree>/dev/null
status=`echo $?`
#rm $output_tree


cd $CURRENT_DIRECTORY
exit $status
