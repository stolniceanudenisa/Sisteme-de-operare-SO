#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR

username=`cat input_param`

p=`ps -u $username | wc -l`
np=`expr $p - 1`
echo $np >output.ok


#cleanup
cd $PWD
