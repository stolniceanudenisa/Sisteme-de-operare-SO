#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
mkdir dir1
mkdir dir2
mkdir dir3
mkdir dir4

cd ./dir1
cp /etc/passwd ./passwd
echo "#include <string.h>"> ./passwd.c
cp /etc/group ./group
echo "#include <string.h>"> ./group.c
echo "ceva"> altceva.txt
mkdir subdir1
echo "#include <string.h>"> subdir1.c
cd subdir1
touch 'fisiergol.txt'
echo "#include <string.h>"> 'fisiergol.txt.c'
echo not empty>'fisiercarenuegol.txt'
echo "#include <string.h>"> 'fisiercarenuegol.txt.c'
echo "abd">abdc
echo "asdqw">>abdc
echo "#include <string.h>">abdc.c
echo "Cum sa ajungi pe prima pagina pe Google - marketing online">google
echo "De multe ori lumea ne intreaba care sunt pasii ce trebuie urmati pentru a ajunge pe prima pagina a motorului de cautare Google.">>google
echo "#include <string.h>"> google.c
cd ..
mkdir subdir2
cd subdir2
echo "nimic important">critical
echo "#include <string.h>"> critical.c
cp /bin/ls ./ls2
echo "#include <string.h>"> ls2.c
cd ../../
cd dir3
mkdir subtitle
cd ./subtitle
mkdir title
cd ../../
cd dir4

#cleanup
cd $PWD
