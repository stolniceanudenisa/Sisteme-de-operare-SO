#!/bin/bash

#prepare
PWD=`pwd`
WORK_DIR=`dirname $0`
WORK_DIR=`readlink -f $WORK_DIR`
cd $WORK_DIR/execute

#create dirs and 
mkdir dir1
mkdir dir2
mkdir dir3
mkdir dir4

cp /bin/ls ./bin1
cp /etc/passwd ./passwd
cp /etc/group ./group
touch ceva.txt
echo "ceva"> altceva.txt
mkdir subdir1
chmod 777 subdir1
cd subdir1
touch 'fisier gol'
chmod 453 'fisier gol'
echo not empty>'fisier care nu e gol'
chmod 123 'fisier care nu e gol'
echo "abd">abdc
echo "asdqw">>abdc
chmod 100 abdc
echo "Cum sa ajungi pe prima pagina pe Google - marketing online">google
echo "De multe ori lumea ne intreaba care sunt pasii ce trebuie urmati pentru a ajunge pe prima pagina a motorului de cautare Google.">>google
chmod 412 google
cd ..
mkdir subdir2
cd subdir2
echo "nimic important">critical
chmod 235 critical
cp /bin/ls ./ls2
chmod 444 ls2
cd ../
cd dir3
mkdir subtitle
cd ./subtitle
mkdir title

cd $WORK_DIR
param1=`cat input_param`
./solution.sh ./execute/$param1 >output.ok

#cleanup
cd $PWD
